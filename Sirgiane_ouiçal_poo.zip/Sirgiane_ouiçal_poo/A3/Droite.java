
public class Droite {
    private Point sommet;
    private Vecteur direction;

    public Droite(Point sommet, Vecteur direction) {
        this.sommet = sommet;
        this.direction = direction;
    }

}
