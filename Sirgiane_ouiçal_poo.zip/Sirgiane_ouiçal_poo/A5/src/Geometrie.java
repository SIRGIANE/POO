public interface Geometrie {
    double perimetre();
    double surface();
}
