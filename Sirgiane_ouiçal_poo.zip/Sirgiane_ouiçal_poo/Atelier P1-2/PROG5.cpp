#include <iostream>
using namespace std;

class Complexe {
private:
    double reel, imaginaire;

public:
    Complexe(double Re, double Im) : reel(Re), imaginaire(Im) {}

    void afficher() {
        if (imaginaire >= 0) {
            cout << reel << " + " << imaginaire << "i" << endl;
        }else{
        cout << reel << imaginaire << "i" << endl;
        }}
    Complexe operator+(const Complexe& autre) const {
        double reel_sum = reel + autre.reel;
        double imaginaire_sum = imaginaire + autre.imaginaire;
        return Complexe(reel_sum, imaginaire_sum);
    }

    Complexe addTrois(const Complexe& autre1, const Complexe& autre2) const {
        double reel_sum = reel + autre1.reel + autre2.reel;
        double imaginaire_sum = imaginaire + autre1.imaginaire + autre2.imaginaire;
        return Complexe(reel_sum, imaginaire_sum);
    }};
/*
    Complexe operator-(const Complexe& autre){
        double reel_diff = reel - autre.reel;
        double imaginaire_diff = imaginaire - autre.imaginaire;
        return Complexe(reel_diff, imaginaire_diff);
    }

    Complexe operator*(const Complexe& autre) {
    double reel_result = (reel * autre.reel) - (imaginaire * autre.imaginaire);
    double imaginaire_result = (reel * autre.imaginaire) + (imaginaire * autre.reel);
    return Complexe(reel_result, imaginaire_result);
    }
};
*/

int main() {
    double R1, I1, R2, I2,R3,I3;
    cout << "Entrez la partie reelle du premier nombre : ";
    cin >> R1;
    cout << "Entrez sa partie imaginaire: ";
    cin >> I1;
    cout << "Entrez la partie reelle du deuxieme nombre : ";
    cin >> R2;
    cout << "Entrez sa partie imaginaire : ";
    cin >> I2;
    cout << "Entrez la partie reelle du 3eme nombre : ";
    cin >> R3;
    cout << "Entrez sa partie imaginaire : ";
    cin >> I3;

    Complexe c1(R1, I1);
    Complexe c2(R2, I2);
    Complexe c3(R3,I3);
    cout << "Le nombre complexe c1 que vous avez saisi : ";
    c1.afficher();
    cout << "Le nombre complexe c2 que vous avez saisi : ";
    c2.afficher();
    cout << "Le nombre complexe c3 que vous avez saisi : ";
    c3.afficher();
    
Complexe somme=c1+c2+c3;
//sustraction=c1-c2,prod=c1*c2;
    cout << "Resultat de l'addition : ";
    somme.afficher();
    cout << "Resultat de la soustraction : ";
   // sustraction.afficher();
    cout << "Resultat de la multiplication : ";
    //prod.afficher();
    return 0;
}
