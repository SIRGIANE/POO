#include<iostream>
#include<string>
#include<cmath> //pour sqrt
using namespace std;

class Localisation {
private:
    int x, y;
    string description;
public:
    Localisation(int, int);
    Localisation(int, int, string);
    void Changerxy(int, int);
    void ChangerDecription(string desc);
    void affiche() {cout << "x: " << x << "\ny:" << y << "\nDescription: " << description << endl; }

    friend double Distance(Localisation& loc1,Localisation& loc2);
};

Localisation::Localisation(int a, int b, string desc) {
    x = a;
    y = b;
    description = desc;
}

void Localisation::Changerxy(int nx, int ny) {
    x = nx;
    y = ny;
}

void Localisation::ChangerDecription(string desc) {
    description = desc;
}
// definition de la fonction Distance
double Distance(Localisation& loc1,Localisation& loc2) {
    int dx = loc1.x - loc2.x;
    int dy = loc1.y - loc2.y;
    return sqrt(dx * dx + dy * dy);
}

int main() {
    Localisation P(10, 20, "Boutique");
    Localisation Q(30, 40, "Maison");
    P.affiche();
    Q.affiche();
    double dist = Distance(P, Q);
    cout << "Distance entre P et Q: " << dist << endl;
    return 0;
}