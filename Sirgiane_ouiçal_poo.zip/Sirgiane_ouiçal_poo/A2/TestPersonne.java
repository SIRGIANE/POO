public class TestPersonne{
public static void main(String[] args){
        Personne P1=new Personne("ouical",20);
        P1.afficher();
        }
}
