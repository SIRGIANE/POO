public class Personne {
    private String nom;
    private int age;

    public Personne(String nom, int age) {
        this.nom = nom;
        this.age = age;
    }
    public void getNom() {System.out.println("new nom for P1:  "+nom);}
    public void setNom(String S) {this.nom = S;}
    public void getAge() {
        System.out.println("new age for P1: "+age);
    }
    public void setAge(int a) {
        this.age = a;
    }
    public void afficher() {
        System.out.println("NOM: " + nom);
        System.out.println("AGE: " + age);
    }
}
