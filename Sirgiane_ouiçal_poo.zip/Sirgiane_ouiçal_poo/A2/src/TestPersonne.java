import java.util.Scanner;

public class TestPersonne {
        public static void main(String[] args) {
                Personne P1 = new Personne("ouical", 20);
                Personne P2 = new Personne("hi", 30);
                P1.afficher();

                Scanner scanA = new Scanner(System.in);
                System.out.println("Entrer l'âge : ");
                int a = scanA.nextInt();
                P1.setAge(a);

                Scanner scanN = new Scanner(System.in);
                System.out.println("Entrer le nom : ");
                String s = scanN.next();
                P1.setNom(s);

                P1.getNom();
                P1.getAge();
        }
}

