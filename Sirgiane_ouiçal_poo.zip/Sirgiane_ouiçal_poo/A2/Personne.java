public class Personne {
    private String nom;
    private int age;

    public Personne(String nom, int age) {
        this.nom = nom;
        this.age = age;
    }

    public String getNom() {
        return nom;
    }

    public void setNom() {
        this.nom = nom;
    }

    public int getAge() {
        return age;
    }

    public void setAge() {
        this.age = age;
    }
    public void afficher() {
        System.out.println("NOM: " + nom);
        System.out.println("AGE: " + age);
    }
}
