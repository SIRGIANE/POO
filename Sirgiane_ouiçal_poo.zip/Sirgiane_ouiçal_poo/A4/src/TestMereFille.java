public class TestMereFille {
    public static void main(String[] arg){
        Mere m=new Mere(7,6);
        Fille f=new Fille(11,4,25);
    }
}
