public class D extends C{
    public void affiche(){
        System.out.println("je suis un D");
    }
}
