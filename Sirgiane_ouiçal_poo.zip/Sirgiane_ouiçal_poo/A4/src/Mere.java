public class Mere {
    protected int a;
    protected int b=5;
    public Mere(int aa, int bb){
        System.out.println("Debut Mere:"+"a= "+a+ "b= "+b);
        a=aa;b=bb;
        System.out.println("Fin Mere: "+"a= "+a+"b= "+b);
    }
}
