public class TestABCDEF {
    public static void main(String[]arg){
        A a=new A(); a.affiche(); B b=new B(); b.affiche();
        C c=new C(); c.affiche(); D d=new D(); d.affiche();
        E e=new E(); e.affiche(); F f=new F(); f.affiche();
    }
}
