public class C extends A{
    public void affiche(){System.out.println("je suis un C");}
}
