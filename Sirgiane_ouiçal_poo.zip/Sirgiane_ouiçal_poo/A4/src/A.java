public class A {
    public void affiche(){System.out.println("je suis un A");}
}
