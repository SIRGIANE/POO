public class Err extends Exception  {
}
